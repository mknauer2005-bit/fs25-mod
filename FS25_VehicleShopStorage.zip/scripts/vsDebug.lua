---Simple debug function that does stuff with different types of vars.  
function vsDebug(data)
  local debug = false
  if debug then
    if data ~= nil then
      -- Run if data is table
      if type(data) == "table" then
        print("** VSS Debug - Table **")
        DebugUtil.printTableRecursively(data, "  tabledata : ", 0, 1)
      -- Run if data is boolean
      elseif type(data) == "boolean" then
        if data == true then 
          print("** VSS Debug - Boolean ** : true")
        else 
          print("** VSS Debug - Boolean ** : false")
        end
      -- Run if data is number
      elseif type(data) == "number" then
        print("** VSS Debug - Number ** : " .. data)
      -- Run if data is string
      elseif type(data) == "string" then
        print("** VSS Debug - String ** : " .. data)
      -- Run if data is function
      elseif type(data) == "function" then
        print("** VSS Debug - Function ** : ")
        print(data)
      -- Run if data is thread
      elseif type(data) == "thread" then
        print("** VSS Debug - Thread ** : ")
        print(data)
      -- Run if nothing else
      else
        print("** VSS Debug ** : " .. data)
      end
    else
      print("** VSS Debug ** : nil")
    end
  end
end